const header = document.querySelector('.site-header');
const menuBtn = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav-links');
const phone = '923101129666';

window.addEventListener('scroll', () => header.classList.toggle('scrolled', window.scrollY > 40));
menuBtn.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', String(open));
});
document.querySelectorAll('.nav-links a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

document.querySelectorAll('[data-service]').forEach(card => {
  const service = card.dataset.service;
  const msg = `Hi Sunia Hassan Makeover Lounge, I'd like to ask about ${service}. Please share the price and available timings.`;
  card.href = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
  card.target = '_blank';
  card.rel = 'noopener';
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
document.getElementById('year').textContent = new Date().getFullYear();
