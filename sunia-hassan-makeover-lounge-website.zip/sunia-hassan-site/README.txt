SUNIA HASSAN MAKEOVER LOUNGE WEBSITE

Files:
- index.html  : Website content and structure
- style.css   : Colors, layout, responsive design and animations
- script.js   : Mobile menu, service-specific WhatsApp links and scroll animations

Business details used:
Sunia Hassan Makeover Lounge
Stadium Rd, Sargodha, 40100, Pakistan
Phone: +92 310 1129666

Opening hours used from the current business listing:
Mon 10:30 AM–7:30 PM
Tue 10:30 AM–7:30 PM
Wed 10:30 AM–7:30 PM
Thu 9:30 AM–7:30 PM
Fri 9:00 AM–7:00 PM
Sat 10:30 AM–7:30 PM
Sun 10:30 AM–7:30 PM

Editing:
- Change text directly in index.html.
- Change colors from the :root variables at the top of style.css.
- Replace Unsplash image URLs in index.html with the salon's own photos.
- Change WhatsApp number in both index.html and the 'phone' variable in script.js.

Note:
Gallery/hero images are generic high-quality lifestyle images used for presentation only and are labeled accordingly on the page.
